/*
|--------------------------------------------------------------------------
| Command Prefix
|--------------------------------------------------------------------------
|
| This is the prefix of the commands that are send in chat
| changing this changes what people have to type in before using
| a command for instance: -help. (-) is the command prefix.
|
*/
export const PREFIX = "-";
