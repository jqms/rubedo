/*
|--------------------------------------------------------------------------
| Objectives
|--------------------------------------------------------------------------
|
| This is a list of all objectives this pack uses
| please add any objective to this list so it can be added at world creation
| make sure to add them beofre sending pack to others and new worlds.
|
*/
export const OBJECTIVES: Array<Object> = [];
