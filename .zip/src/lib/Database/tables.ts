import type { IRegionDB } from "../../modules/models/Region";
import type { IMuteData } from "../../modules/models/Mute";
import type { IBanData } from "../../modules/models/Ban";
import type { IFreezeData } from "../../modules/models/Freeze";
import type { ROLES } from "../../config/staff";
import { Database } from "../../lib/Database/Database";

/**
 * All the Database tables that are created
 */
export const TABLES = {
  config: new Database<any>("config"),
  freezes: new Database<IFreezeData>("freezes"),
  mutes: new Database<IMuteData>("mutes"),
  bans: new Database<IBanData>("bans"),
  regions: new Database<IRegionDB>("regions"),
  roles: new Database<keyof typeof ROLES>("roles"),
  tasks: new Database<any>("tasks"),
};
