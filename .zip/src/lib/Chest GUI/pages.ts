import { Page } from "./Models/Page";

interface IPAGES { 
    [key: string]: Page
}

export const PAGES: IPAGES = {};
