import { Player } from "mojang-minecraft";
import { TABLES } from "../../lib/Database/tables.js";
import { getId, MS } from "../../utils.js";

export interface IMuteData {
  player: string;
  date: number;
  length: number | null;
  expire: number | null;
  reason: string;
  by: string;
}

export class Mute {
  length: number;
  /**
   * Gets the mute data for this player
   * @param {Player} player player to get
   * @returns {muteData | null}
   */
  static getMuteData(player: Player) {
    return TABLES.mutes.get(getId(player));
  }
  /**
   * Mutes a player for a length
   */
  constructor(
    player: Player,
    length?: number,
    unit?: string,
    reason: string = "No Reason",
    by: string = "Smelly Anti Cheat"
  ) {
    player.runCommand(`ability @s mute true`);
    const msLength = length ? MS(`${length} ${unit}`) : null;
    const data: IMuteData = {
      player: getId(player),
      date: Date.now(),
      length: msLength,
      expire: msLength ? msLength + Date.now() : null,
      reason: reason,
      by: by,
    };
    TABLES.mutes.set(getId(player), data);
  }
}
