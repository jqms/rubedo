import { Player } from "mojang-minecraft";
import { TABLES } from "../../lib/Database/tables.js";
import { getId } from "../../utils.js";

export interface IFreezeData {
  player: string;
  key: string;
  reason: string;
  location: {
    x: number;
    y: number;
    z: number;
    dimension: string;
  };
}

export class Freeze {
  /**
   * Freeze a player
   */
  constructor(player: Player, reason: string = "No Reason") {
    const data = {
      player: player.name,
      key: getId(player),
      reason: reason,
      location: {
        x: player.location.x,
        y: player.location.y,
        z: player.location.z,
        dimension: player.dimension.id,
      },
    };
    TABLES.freezes.set(getId(player), data);
  }
}
