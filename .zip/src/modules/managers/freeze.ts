import { Location } from "mojang-minecraft";
import { TABLES } from "../../lib/Database/tables.js";
import { DIMENSIONS, forEachValidPlayer, getId } from "../../utils.js";

forEachValidPlayer((player) => {
  const freezeData = TABLES.freezes.get(getId(player));
  if (!freezeData) return;
  player.teleport(
    new Location(
      freezeData.location.x,
      freezeData.location.y,
      freezeData.location.z
    ),
    DIMENSIONS[freezeData.location.dimension as keyof typeof DIMENSIONS],
    0,
    0
  );
}, 20);
