/*
|--------------------------------------------------------------------------
| Managers
|--------------------------------------------------------------------------
|
| This is an array of all the MANAGER files that should be enabled
| removing a name from this list will disable the MANAGER
| please make sure this is the files name
|
*/
import "./ban";
import "./freeze";
import "./mute";
import "./region";
import "./playerJoin";
